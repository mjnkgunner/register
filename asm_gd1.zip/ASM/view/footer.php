<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<link rel="stylesheet" href="view/style.css">
<body>
  <footer>
      <div class="logo_end">
        <div>
          <div class="logo_footer"><img src="view/img/logo.png" alt="" /></div>
          <p>corner by Linh</p>
          <div class="more">
            <img src="./fbpng.webp" alt="" />
            <img src="./igpng.webp" alt="" />
            <img src="./youtubepng.png" alt="" />
            <img src="./inpng.webp" alt="" />
          </div>
        </div>
      </div>
      <div class="lienhe">
        <div>
          <div class="lienhe_link">
            <a href="">topic</a>
            <a href="">topic</a>
            <a href="">topic</a>
          </div>
          <div class="lienhe_link">
            <a href="">page</a>
            <a href="">page</a>
            <a href="">page</a>
          </div>
          <div class="lienhe_link">
            <a href="">page</a>
            <a href="">page</a>
            <a href="">page</a>
          </div>
          <div class="lienhe_link">
            <a href="">page</a>
            <a href="">page</a>
            <a href="">page</a>
          </div>
        </div>
      </div>
    </footer>
</body>
</html>