    <section>
      <div class="topwek">
        <h1>TOP NỔI BẬT TRONG TUẦN</h1>
        <div id="anhv1" class="anh1">
          <img src="view/img/applewatch_hong.png" alt="" />
        </div>
        <div id="anhv2" class="anh2">
          <img src="view/img/applewatch_den.png" alt="" />
        </div>
        <div id="anhv3" class="anh3">
          <img src="view/img/applewatch_trang.png" alt="" />
        </div>
        <div class="btn_luachon">
          <button class="btn_v1" onclick="tien()"></button>
          <button class="btn_v2" onclick="lui()"></button>
        </div>
        <div class="name_topwek">
          <h2>Apple Watch Series 4 GPS 40mm NHÔM (Likenew 99%)</h2>
        </div>
      </div>
    </section>
    <section class="hang">
      <div class="hanghoa">
        <div>
          <img src="view/img/ip16.jpg" alt="" />
          <h3 class="Hang1">Iphone 16 promax</h3>
          <button class="btn_addtocard">them vao gio hang</button>
          <button class="btn_buynow">Mua Ngay</button>
        </div>
      </div>
    </section>