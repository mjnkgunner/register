<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<?php



?>
<body>
    <h1>
        day la trang chu
    </h1>

    <a href="?page=home">Trang chu</a>
    <a href="?page=SinhVien">Danh sach sinh vien</a>
</body>
</html>