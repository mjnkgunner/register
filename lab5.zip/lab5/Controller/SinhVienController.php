<?php
class addsvController {
    private $db;
    private $sinhviens;

    public function __construct() {
        require_once "Model/StudentModel.php"; // đảm bảo đúng đường dẫn
        $this->db = new addSinhVien; // SỬA CHỖ NÀY
    }

    public function getAll() {
        $conn = $this->db->getConnection(); // hoặc addsv() nếu đó là tên hàm kết nối
        $sql = "SELECT * FROM sinhvien";

        $result = $conn->query($sql);
        if (!$result) {
            die("Query failed: " . $conn->error);
        }

        $sinhviens = $result->fetch_all(MYSQLI_ASSOC);
        $result->free(); // giải phóng bộ nhớ
        return $sinhviens;
    }
}
?>