<?php
require_once "Controller/SinhVienController.php";

$SinhVienA = new addsvController();

// Lấy danh sách sinh viên từ controller và gán vào biến
$sinhvienp = $SinhVienA->getAll();
// print_r($sinhvienp);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh sách sinh viên</title>
    <style>
        .tabole{
            border: 1px solid black;
        }
    </style>
</head>
<body>
    <?php foreach ($sinhvienp as $product): ?>
<div class="tabole">
            <p><?= $product['ID']; ?></p>
            <h1><?= $product['Name']; ?></h1>
<a href="?page=chitietModel&id=<?= htmlspecialchars($product['ID']) ?>">xem chi tiết</a>
</div>
    <?php endforeach; ?>
</body>
</html>